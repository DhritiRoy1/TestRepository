﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Threading;
using UnityEngine;
using UnityEngine.UI;

public class Ball : MonoBehaviour
{
    public int Lscore = 0;
    public int Rscore = 0;
    float speed = 10;
    float radius;
    Vector2 direction;
    Vector3 tempPos;
    String Winner;
    
    // Start is called before the first frame update
    void Start()
    {
        tempPos = transform.position;
        direction = Vector2.one.normalized;
        radius = transform.localScale.x / 2;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(direction * speed * Time.deltaTime);
        if (transform.position.y < GameManager.bottomLeft.y + radius && direction.y < 0)
        {
            direction.y = -direction.y;
        }
        else if (transform.position.y> GameManager.TopRight.y - radius && direction.y > 0)
        {
            direction.y = -direction.y;
        }
        else if (transform.position.x > 2*GameManager.TopRight.y && direction.x > 0)
        {
            Lscore++;
            GameManager.LeftStringcounter = Lscore.ToString();
            if (Lscore == 3)
            {
                String Winner = "Left Player wins!";
                GameManager.WinnerMessage = Winner;
                Time.timeScale = 0.0f;
            }
            //UnityEngine.Debug.Log ("Left player wins!!");
            //UnityEngine.Debug.Log(Lscore);
            tempPos.x = 0;
            tempPos.y = 0;
            transform.position = tempPos;
            direction = Vector2.one.normalized;
        }
        else if (transform.position.x < (GameManager.bottomLeft.x) && direction.x < 0)
        {
            Rscore++;
            GameManager.RightStringcounter = Rscore.ToString();
            if(Rscore == 3)
            {
                String Winner = "Right Player wins!";
                GameManager.WinnerMessage = Winner;
                Time.timeScale = 0.0f;
            }
            //UnityEngine.Debug.Log("Left player wins!!");
            //UnityEngine.Debug.Log(Rscore);
            tempPos.x = 0;
            tempPos.y = 0;
            transform.position = tempPos;
            direction = Vector2.one.normalized;
        }

    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Paddle")
        {
                direction.x = -direction.x;
        }

    }
}

