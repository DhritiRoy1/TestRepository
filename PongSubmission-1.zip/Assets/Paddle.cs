﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using UnityEngine;

public class Paddle : MonoBehaviour
{
    float speed;
    float height;
    string input;
    bool isRight;
    float move;
    // Start is called before the first frame update
    void Start()
    {
        height = transform.localScale.y;
        speed = 10f;
    }

    public void Init(bool isRightPaddle)
    {
        isRight = isRightPaddle;
        Vector2 pos = Vector2.zero;
        if (isRightPaddle)
        {
            pos = new Vector2(GameManager.TopRight.x, 0);
            pos -= Vector2.right * transform.localScale.x;
            input = "PaddleRight";
        }
        else
        {
            pos = new Vector2(GameManager.bottomLeft.x, 0);
            pos += Vector2.right * transform.localScale.x;
            input = "PaddleLeft";
        }
        transform.position = pos;
        transform.name = input;

    }

    // Update is called once per frame
    void Update()
    {
        move = Input.GetAxis(input) * Time.deltaTime * speed;
        Console.WriteLine(Screen.height);
        if (transform.position.y < GameManager.bottomLeft.y+(height/2) && move<0)
        {
            move = 0f;
            transform.Translate(move * Vector2.up);
        }
        if (transform.position.y > GameManager.TopRight.y-(height / 2) && move > 0)
        {
            move = 0f;
            transform.Translate(move * Vector2.up);
        }
        transform.Translate(move * Vector2.up);
     }
           

 }

