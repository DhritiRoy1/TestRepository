﻿using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Security.Cryptography;
using System.Threading;
using UnityEngine;
using UnityEngine.UI;


public class GameManager : MonoBehaviour
{
    public GameObject LeftScore;
    public GameObject RightScore;
    public GameObject Winner;
    public Ball ball;
    public Paddle paddle;
    public static Vector2 bottomLeft;
    public static Vector2 TopRight;
    public static string LeftStringcounter;
    public static string RightStringcounter;
    public static string WinnerMessage;
    //Start is called before the first frame update
    void Start()
    {
        //score.GetComponent<Text>().text = "test";
        bottomLeft = Camera.main.ScreenToWorldPoint(new Vector2(0, 0));
        TopRight = Camera.main.ScreenToWorldPoint(new Vector2(Screen.width, Screen.height));
        Instantiate(ball);
        Paddle paddle1 = Instantiate(paddle) as Paddle;
        Paddle paddle2 = Instantiate(paddle) as Paddle;
        paddle1.Init(true);
        paddle2.Init(false);
    }


    // Update is called once per frame
    void Update()
    {
        UnityEngine.Debug.Log(LeftStringcounter);
        UnityEngine.Debug.Log(RightStringcounter);
        LeftScore.GetComponent<Text>().text = "score: "+LeftStringcounter;
        RightScore.GetComponent<Text>().text = "score: " + RightStringcounter;
        Winner.GetComponent<Text>().text = WinnerMessage;
        //paddle1.Update();
        //paddle2.Update();

    }
}
